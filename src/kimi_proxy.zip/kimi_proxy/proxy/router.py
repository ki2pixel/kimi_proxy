"""
Routing des requêtes vers les providers.

Phase 3: Routage optimisé basé sur la capacité contexte restante.
"""
from typing import Dict, Any, Optional, List
from dataclasses import dataclass

from ..core.constants import DEFAULT_MAX_CONTEXT, DEFAULT_PROVIDER
from ..core.models import ProviderRoutingDecision

def get_target_url_for_session(
    session: dict,
    providers: Dict[str, Dict[str, Any]]
) -> str:
    """
    Récupère l'URL cible pour la session en fonction du provider.
    
    Args:
        session: Session active
        providers: Dictionnaire des providers configurés
        
    Returns:
        URL cible pour les appels API
    """
    if not session:
        return "https://api.kimi.com/coding/v1"
    
    provider_key = session.get("provider", DEFAULT_PROVIDER)
    provider = providers.get(provider_key, {})
    base_url = provider.get("base_url", "")
    
    # Protection contre la boucle infinie
    if base_url and "127.0.0.1:8000" not in base_url and "localhost:8000" not in base_url:
        return base_url.rstrip("/")
    
    return "https://api.kimi.com/coding/v1"

def get_provider_host_header(target_url: str) -> Optional[str]:
    """
    Extrait le header Host approprié pour l'URL cible.
    
    Args:
        target_url: URL cible
        
    Returns:
        Header Host ou None
    """
    try:
        from urllib.parse import urlparse
        parsed = urlparse(target_url)
        return parsed.netloc
    except Exception:
        return None

def find_heavy_duty_model(
    provider_key: str,
    current_model: str,
    required_context: int,
    models: Dict[str, Dict[str, Any]]
) -> Optional[str]:
    """
    Trouve un modèle avec plus de contexte dans le même provider.
    
    Args:
        provider_key: Clé du provider
        current_model: Modèle actuel
        required_context: Contexte minimum requis
        models: Dictionnaire des modèles
        
    Returns:
        Clé du modèle fallback ou None
    """
    current_model_data = models.get(current_model, {})
    current_context = current_model_data.get("max_context_size", DEFAULT_MAX_CONTEXT)
    
    candidates = []
    for model_key, model_data in models.items():
        if model_data.get("provider") == provider_key:
            model_context = model_data.get("max_context_size", DEFAULT_MAX_CONTEXT)
            if model_context > current_context and model_context >= required_context:
                candidates.append((model_key, model_context))
    
    if not candidates:
        return None
    
    candidates.sort(key=lambda x: x[1])
    return candidates[0][0]

def get_max_context_for_session(
    session: dict,
    models: Dict[str, Dict[str, Any]],
    default: int = DEFAULT_MAX_CONTEXT
) -> int:
    """
    Récupère le contexte max pour une session.
    
    Args:
        session: Session active
        models: Dictionnaire des modèles
        default: Valeur par défaut
        
    Returns:
        Taille de contexte maximale
    """
    if not session:
        return default
    
    provider_key = session.get("provider", DEFAULT_PROVIDER)
    model_key = session.get("model")
    
    # Si un modèle spécifique est stocké, utilise son contexte
    if model_key and model_key in models:
        return models[model_key].get("max_context_size", default)
    
    # Sinon, trouve le contexte le plus petit parmi les modèles du provider
    min_context = None
    for mk, model in models.items():
        if model.get("provider") == provider_key:
            ctx = model.get("max_context_size", default)
            if min_context is None or ctx < min_context:
                min_context = ctx
    
    return min_context if min_context else default

def map_model_name(
    client_model: str,
    models: Dict[str, Dict[str, Any]]
) -> str:
    """
    Mappe le nom du modèle client vers le nom provider.
    
    Args:
        client_model: Nom du modèle envoyé par le client (format JetBrains avec -)
        models: Dictionnaire des modèles configurés (avec / ou .)

    Returns:
        Nom du modèle pour l'API provider
    """
    # 0. La Ruse: retirer les préfixes JetBrains si présents
    base_client_model = client_model

    # Nouveau préfixe JetBrains (gpt-4o-proxy-)
    if client_model.startswith("gpt-4o-proxy-"):
        base_client_model = client_model[13:]  # Retirer "gpt-4o-proxy-"
    # Ancien préfixe avec openai-
    elif client_model.startswith("openai-gpt-4-proxy-"):
        base_client_model = client_model[19:]  # Retirer "openai-gpt-4-proxy-"
    # Compatibilité descendante avec l'ancien préfixe gpt-4-
    elif client_model.startswith("gpt-4-"):
        base_client_model = client_model[6:]  # Retirer "gpt-4-"

    # 1. Vérifier d'abord si c'est une clé exacte
    if base_client_model in models:
        return models[base_client_model].get("model", base_client_model)

    # 2. Itérer sur toutes les clés du dictionnaire et comparer avec normalisation
    for model_key, model_data in models.items():
        # Générer le format JetBrains depuis la clé configurée
        # Ex: "nvidia/kimi-k2.5" -> "nvidia-kimi-k2-5"
        normalized_key = model_key.replace("/", "-").replace(".", "-")

        if normalized_key == base_client_model:
            return model_data.get("model", model_key)

    # 3. Fallback historique pour la rétrocompatibilité
    # Gérer les anciennes clés avec underscores
    original_model_key = base_client_model.replace("_", "/")
    if original_model_key in models:
        return models[original_model_key].get("model", original_model_key)

    # 4. Dernier fallback: retirer le préfixe provider
    if "/" in base_client_model:
        return base_client_model.split("/", 1)[1]

    return base_client_model

# ============================================================================
# Phase 3: Routage Provider Optimisé basé sur Capacité Contexte
# ============================================================================

@dataclass
class ProviderCapacity:
    """Capacité d'un provider."""
    provider_key: str
    model_key: str
    max_context: int
    current_usage: int
    context_remaining: int
    usage_percentage: float
    cost_factor: float  # 1.0 = coût de base
    latency_score: float  # 1.0 = latence de base
    capabilities: List[str]

def get_provider_capacities(
    current_tokens: int,
    models: Dict[str, Dict[str, Any]],
    providers: Dict[str, Dict[str, Any]]
) -> List[ProviderCapacity]:
    """
    Calcule les capacités de tous les providers.
    
    Args:
        current_tokens: Nombre de tokens actuellement utilisés
        models: Dictionnaire des modèles
        providers: Dictionnaire des providers
        
    Returns:
        Liste des capacités triées par contexte restant décroissant
    """
    capacities = []
    
    # Mapping des cost factors par provider (estimation)
    cost_factors = {
        "managed:kimi-code": 1.0,
        "nvidia": 1.2,
        "mistral": 0.8,
        "openrouter": 1.0,
        "siliconflow": 0.6,
        "groq": 0.7,
        "cerebras": 0.8,
        "gemini": 0.9,
    }
    
    # Mapping des latences (estimation relative)
    latency_scores = {
        "managed:kimi-code": 1.0,
        "nvidia": 1.5,  # Peut avoir des cold starts
        "mistral": 1.0,
        "openrouter": 1.2,
        "siliconflow": 1.1,
        "groq": 0.3,  # Ultra-rapide
        "cerebras": 0.4,
        "gemini": 1.3,
    }
    
    for model_key, model_data in models.items():
        provider_key = model_data.get("provider", "")
        max_context = model_data.get("max_context_size", DEFAULT_MAX_CONTEXT)
        
        context_remaining = max_context - current_tokens
        usage_percentage = (current_tokens / max_context * 100) if max_context > 0 else 100
        
        capacities.append(ProviderCapacity(
            provider_key=provider_key,
            model_key=model_key,
            max_context=max_context,
            current_usage=current_tokens,
            context_remaining=context_remaining,
            usage_percentage=usage_percentage,
            cost_factor=cost_factors.get(provider_key, 1.0),
            latency_score=latency_scores.get(provider_key, 1.0),
            capabilities=model_data.get("capabilities", [])
        ))
    
    # Trie par contexte restant décroissant
    capacities.sort(key=lambda x: x.context_remaining, reverse=True)
    return capacities

def calculate_routing_score(capacity: ProviderCapacity, required_tokens: int) -> float:
    """
    Calcule un score de routage pour un provider.
    
    Le score combine:
    - Capacité contexte restante (40%)
    - Coût (30%) - préfère moins cher
    - Latence (20%) - préfère plus rapide
    - Marge de sécurité (10%)
    
    Args:
        capacity: Capacité du provider
        required_tokens: Tokens requis pour la requête
        
    Returns:
        Score de 0 à 1 (plus haut = meilleur)
    """
    if capacity.context_remaining < required_tokens:
        return 0.0  # Insuffisant
    
    # Score de capacité (40%)
    headroom = capacity.context_remaining - required_tokens
    max_headroom = 262144  # Normalisation
    capacity_score = min(headroom / max_headroom, 1.0) * 0.4
    
    # Score de coût (30%) - inverse du cost factor
    cost_score = (1.0 / capacity.cost_factor) * 0.3
    
    # Score de latence (20%) - inverse du latency score
    latency_score = (1.0 / capacity.latency_score) * 0.2
    
    # Score de marge (10%)
    margin = 1.0 - (capacity.usage_percentage / 100)
    margin_score = max(margin, 0) * 0.1
    
    return capacity_score + cost_score + latency_score + margin_score

def find_optimal_provider(
    current_tokens: int,
    required_tokens: int,
    preferred_provider: str,
    models: Dict[str, Dict[str, Any]],
    providers: Dict[str, Dict[str, Any]],
    min_context_buffer: float = 0.1  # 10% de marge minimum
) -> ProviderRoutingDecision:
    """
    Trouve le provider optimal basé sur la capacité contexte restante.
    
    Args:
        current_tokens: Tokens actuellement utilisés
        required_tokens: Tokens requis pour la requête
        preferred_provider: Provider préféré (souvent celui de la session)
        models: Dictionnaire des modèles
        providers: Dictionnaire des providers
        min_context_buffer: Marge minimum requise (0.1 = 10%)
        
    Returns:
        Décision de routage
    """
    # Calcule les capacités
    capacities = get_provider_capacities(current_tokens, models, providers)
    
    # Filtre ceux avec assez de contexte + marge
    min_required = required_tokens * (1 + min_context_buffer)
    viable_capacities = [c for c in capacities if c.context_remaining >= min_required]
    
    if not viable_capacities:
        # Aucun provider viable - fallback sur celui avec le plus de contexte
        if capacities:
            best = capacities[0]
            return ProviderRoutingDecision(
                original_provider=preferred_provider,
                selected_provider=best.provider_key,
                original_model="",
                selected_model=best.model_key,
                required_context=required_tokens,
                available_context=best.max_context,
                context_remaining=best.context_remaining,
                confidence_score=0.3,
                reason="fallback_no_viable_provider",
                fallback_triggered=True,
                estimated_cost=0.0
            )
        else:
            return ProviderRoutingDecision(
                original_provider=preferred_provider,
                selected_provider=preferred_provider,
                original_model="",
                selected_model="",
                required_context=required_tokens,
                available_context=0,
                context_remaining=0,
                confidence_score=0.0,
                reason="no_providers_available",
                fallback_triggered=True,
                estimated_cost=0.0
            )
    
    # Calcule les scores
    scored = [(c, calculate_routing_score(c, required_tokens)) for c in viable_capacities]
    scored.sort(key=lambda x: x[1], reverse=True)
    
    best_capacity, best_score = scored[0]
    
    # Vérifie si le provider préféré est viable
    preferred_capacity = None
    for cap in viable_capacities:
        if cap.provider_key == preferred_provider:
            preferred_capacity = cap
            break
    
    if preferred_capacity:
        preferred_score = calculate_routing_score(preferred_capacity, required_tokens)
        # Si le préféré est dans les 20% du meilleur, garde-le
        if preferred_score >= best_score * 0.8:
            return ProviderRoutingDecision(
                original_provider=preferred_provider,
                selected_provider=preferred_capacity.provider_key,
                original_model=preferred_capacity.model_key,
                selected_model=preferred_capacity.model_key,
                required_context=required_tokens,
                available_context=preferred_capacity.max_context,
                context_remaining=preferred_capacity.context_remaining,
                confidence_score=preferred_score,
                reason="preferred_provider_viable",
                fallback_triggered=False,
                estimated_cost=required_tokens * preferred_capacity.cost_factor / 1000000
            )
    
    # Fallback vers le meilleur
    return ProviderRoutingDecision(
        original_provider=preferred_provider,
        selected_provider=best_capacity.provider_key,
        original_model=preferred_capacity.model_key if preferred_capacity else "",
        selected_model=best_capacity.model_key,
        required_context=required_tokens,
        available_context=best_capacity.max_context,
        context_remaining=best_capacity.context_remaining,
        confidence_score=best_score,
        reason="optimal_provider_selected",
        fallback_triggered=preferred_provider != best_capacity.provider_key,
        estimated_cost=required_tokens * best_capacity.cost_factor / 1000000
    )

def get_routing_recommendation(
    session: dict,
    prompt_tokens: int,
    models: Dict[str, Dict[str, Any]],
    providers: Dict[str, Dict[str, Any]]
) -> Dict[str, Any]:
    """
    Génère une recommandation de routage pour une requête.
    
    Args:
        session: Session active
        prompt_tokens: Tokens du prompt
        models: Dictionnaire des modèles
        providers: Dictionnaire des providers
        
    Returns:
        Recommandation détaillée
    """
    if not session:
        return {
            "recommendation": "use_default",
            "provider": DEFAULT_PROVIDER,
            "reason": "no_active_session"
        }
    
    preferred = session.get("provider", DEFAULT_PROVIDER)
    current_tokens = session.get("estimated_tokens", 0)
    required = prompt_tokens
    
    decision = find_optimal_provider(
        current_tokens=current_tokens,
        required_tokens=required,
        preferred_provider=preferred,
        models=models,
        providers=providers
    )
    
    return {
        "recommendation": "fallback" if decision.fallback_triggered else "continue",
        "decision": decision.to_dict(),
        "savings_estimate": decision.estimated_cost if decision.fallback_triggered else 0.0,
        "context_safety": decision.context_remaining / required if required > 0 else 0.0
    }
