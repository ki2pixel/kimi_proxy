"""
Routes API pour la liste des modèles - Compatible JetBrains AI Assistant.

Structure conforme aux attentes du parser Kotlin de JetBrains :
- Format OpenAI-compatible avec champs supplémentaires (context_window, capabilities)
- Endpoint individuel pour validation
- IDs avec préfixe gpt-4o-proxy- pour filtrage UI
"""
from fastapi import APIRouter, HTTPException
from typing import Dict, Any

from ...config.loader import get_config
from ...config.display import get_model_display_name
from ...core.constants import DEFAULT_MAX_CONTEXT

router = APIRouter()


def _sanitize_model_id_for_jetbrains(model_key: str) -> str:
    """
    Convertit une clé de modèle en ID compatible JetBrains.
    
    Remplace /, ., : par - et ajoute le préfixe gpt-4o-proxy-.
    Cela maximise la compatibilité avec le système de cache de JetBrains.
    
    Exemples:
        - "nvidia/kimi-k2.5" -> "gpt-4o-proxy-nvidia-kimi-k2-5"
        - "managed:kimi-code/kimi-for-coding" -> "gpt-4o-proxy-managed-kimi-code-kimi-for-coding"
    """
    # Remplacer les caractères problématiques par des tirets
    base_id = model_key.replace("/", "-").replace(".", "-").replace(":", "-")
    # Ajouter le préfixe standard pour le filtrage UI JetBrains
    return f"gpt-4o-proxy-{base_id}"


def _generate_model_object(model_key: str, model_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Génère un objet modèle au format exact attendu par JetBrains AI Assistant.
    
    Format basé sur Ollama/LiteLLM qui a le plus de succès avec JetBrains.
    """
    # Générer l'ID compatible JetBrains
    client_model_id = _sanitize_model_id_for_jetbrains(model_key)
    
    # Utiliser le max_context_size du modèle ou la valeur par défaut
    context_window = model_data.get("max_context_size", DEFAULT_MAX_CONTEXT)
    
    # Déterminer les capacités
    capabilities = model_data.get("capabilities", [])
    has_chat_completion = True  # Tous nos modèles supportent le chat
    has_completion = "completion" in capabilities or True  # Most models support completion
    
    # Timestamp fixe (peut être rendu dynamique si nécessaire)
    # Utilisons un timestamp récent mais stable
    created_timestamp = 1704067200  # 2024-01-01 00:00:00 UTC
    
    return {
        "id": client_model_id,
        "object": "model",
        "created": created_timestamp,  # ENTIER UNIQUEMENT (pas de string)
        "owned_by": "openai",  # Force à openai pour maximiser la compatibilité
        "context_window": context_window,  # CRUCIAL pour JetBrains
        "capabilities": {
            "chat_completion": has_chat_completion,  # Débloque l'affichage dans le menu Chat
            "completion": has_completion
        },
        "permission": [{
            "id": "modelperm-dummy",
            "object": "model_permission",
            "allow_chat_completion": True,
            "allow_create_engine": True,
            "allow_sampling": True,
            "allow_view": True,
            "is_blocking": False
        }]
    }


@router.get("")
async def openai_models():
    """
    Endpoint OpenAI-compatible GET /models pour Continue.dev et JetBrains.
    
    Retourne la liste des modèles au format attendu par JetBrains AI Assistant.
    Structure: {"object": "list", "data": [model1, model2, ...]}
    """
    config = get_config()
    models_config = config.get("models", {})
    
    models_list = []
    for model_key, model_data in models_config.items():
        models_list.append(_generate_model_object(model_key, model_data))
    
    # Forcer le Content-Type correct
    return {
        "object": "list",
        "data": models_list
    }


@router.get("/{model_id}")
async def get_model_by_id(model_id: str):
    """
    Endpoint GET /models/{model_id} pour la validation individuelle JetBrains.
    
    Cet endpoint est INDISPENSABLE pour que JetBrains valide chaque modèle
    individuellement avant de l'afficher dans l'UI.
    
    Args:
        model_id: ID du modèle (ex: "gpt-4o-proxy-nvidia-kimi-k2-5")
        
    Returns:
        Objet modèle unique au format JetBrains
        
    Raises:
        HTTPException 404 si le modèle n'est pas trouvé
    """
    config = get_config()
    models_config = config.get("models", {})
    
    # Convertir l'ID JetBrains en clé de modèle interne
    # Ex: "gpt-4o-proxy-nvidia-kimi-k2-5" -> "nvidia/kimi-k2.5"
    if model_id.startswith("gpt-4o-proxy-"):
        # Rechercher dans tous les modèles configurés
        for model_key, model_data in models_config.items():
            # Générer l'ID JetBrains pour cette clé
            jetbrains_id = _sanitize_model_id_for_jetbrains(model_key)
            if jetbrains_id == model_id:
                # Modèle trouvé !
                return _generate_model_object(model_key, model_data)
        
        # Si on arrive ici, le modèle n'existe pas
        raise HTTPException(
            status_code=404,
            detail=f"Modèle '{model_id}' non trouvé. Vérifiez la configuration."
        )
    else:
        # L'ID n'a pas le préfixe attendu, essayer de le trouver directement
        # pour la compatibilité descendante
        if model_id in models_config:
            return _generate_model_object(model_id, models_config[model_id])
        
        raise HTTPException(
            status_code=404,
            detail=f"Modèle '{model_id}' non trouvé. Format attendu: 'gpt-4o-proxy-provider-model'"
        )


@router.get("/all")
async def api_get_models():
    """
    Retourne tous les modèles disponibles depuis la config (format détaillé interne).
    
    Cet endpoint est utilisé par le dashboard web pour l'affichage détaillé.
    Il n'est pas utilisé par JetBrains AI Assistant.
    """
    config = get_config()
    models_config = config.get("models", {})
    
    result = []
    for model_key, model in models_config.items():
        result.append({
            "key": model_key,
            "model": model.get("model"),
            "name": get_model_display_name(model_key),
            "provider": model.get("provider"),
            "max_context_size": model.get("max_context_size", DEFAULT_MAX_CONTEXT),
            "capabilities": model.get("capabilities", [])
        })
    
    # Trie par provider puis par nom
    result.sort(key=lambda x: (x.get("provider", ""), x.get("name", "")))
    
    return result
